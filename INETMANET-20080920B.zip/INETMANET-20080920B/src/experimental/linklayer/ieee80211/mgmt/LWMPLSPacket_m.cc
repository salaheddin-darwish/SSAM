//
// Generated file, do not edit! Created by opp_msgc 4.1 from experimental/linklayer/ieee80211/mgmt/LWMPLSPacket.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "LWMPLSPacket_m.h"

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
std::ostream& operator<<(std::ostream& out,const T&) {return out;}

// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




EXECUTE_ON_STARTUP(
    cEnum *e = cEnum::find("LwmplsType");
    if (!e) enums.getInstance()->add(e = new cEnum("LwmplsType"));
    e->insert(WMPLS_NORMAL, "WMPLS_NORMAL");
    e->insert(WMPLS_BEGIN, "WMPLS_BEGIN");
    e->insert(WMPLS_REFRES, "WMPLS_REFRES");
    e->insert(WMPLS_END, "WMPLS_END");
    e->insert(WMPLS_BREAK, "WMPLS_BREAK");
    e->insert(WMPLS_NOTFOUND, "WMPLS_NOTFOUND");
    e->insert(WMPLS_ACK, "WMPLS_ACK");
    e->insert(WMPLS_ADITIONAL, "WMPLS_ADITIONAL");
    e->insert(WMPLS_BEGIN_W_ROUTE, "WMPLS_BEGIN_W_ROUTE");
    e->insert(WMPLS_SEND, "WMPLS_SEND");
    e->insert(WMPLS_BROADCAST, "WMPLS_BROADCAST");
    e->insert(WMPLS_MACBASEDLABEL_BEGIN, "WMPLS_MACBASEDLABEL_BEGIN");
    e->insert(WMPLS_MACBASEDLABEL_BEGIN_W_ROUTE, "WMPLS_MACBASEDLABEL_BEGIN_W_ROUTE");
);

Register_Class(LWMPLSPacket);

LWMPLSPacket::LWMPLSPacket(const char *name, int kind) : cPacket(name,kind)
{
    this->setByteLength(4);

    this->label_var = 0;
    this->labelReturn_var = 0;
    this->type_var = 0;
    this->nextHeader_var = false;
    this->counter_var = 0;
    vectorAddress_arraysize = 0;
    this->vectorAddress_var = 0;
}

LWMPLSPacket::LWMPLSPacket(const LWMPLSPacket& other) : cPacket()
{
    setName(other.getName());
    vectorAddress_arraysize = 0;
    this->vectorAddress_var = 0;
    operator=(other);
}

LWMPLSPacket::~LWMPLSPacket()
{
    delete [] vectorAddress_var;
}

LWMPLSPacket& LWMPLSPacket::operator=(const LWMPLSPacket& other)
{
    if (this==&other) return *this;
    cPacket::operator=(other);
    this->label_var = other.label_var;
    this->labelReturn_var = other.labelReturn_var;
    this->type_var = other.type_var;
    this->nextHeader_var = other.nextHeader_var;
    this->counter_var = other.counter_var;
    this->source_var = other.source_var;
    this->dest_var = other.dest_var;
    delete [] this->vectorAddress_var;
    this->vectorAddress_var = (other.vectorAddress_arraysize==0) ? NULL : new ::MACAddress[other.vectorAddress_arraysize];
    vectorAddress_arraysize = other.vectorAddress_arraysize;
    for (unsigned int i=0; i<vectorAddress_arraysize; i++)
        this->vectorAddress_var[i] = other.vectorAddress_var[i];
    return *this;
}

void LWMPLSPacket::parsimPack(cCommBuffer *b)
{
    cPacket::parsimPack(b);
    doPacking(b,this->label_var);
    doPacking(b,this->labelReturn_var);
    doPacking(b,this->type_var);
    doPacking(b,this->nextHeader_var);
    doPacking(b,this->counter_var);
    doPacking(b,this->source_var);
    doPacking(b,this->dest_var);
    b->pack(vectorAddress_arraysize);
    doPacking(b,this->vectorAddress_var,vectorAddress_arraysize);
}

void LWMPLSPacket::parsimUnpack(cCommBuffer *b)
{
    cPacket::parsimUnpack(b);
    doUnpacking(b,this->label_var);
    doUnpacking(b,this->labelReturn_var);
    doUnpacking(b,this->type_var);
    doUnpacking(b,this->nextHeader_var);
    doUnpacking(b,this->counter_var);
    doUnpacking(b,this->source_var);
    doUnpacking(b,this->dest_var);
    delete [] this->vectorAddress_var;
    b->unpack(vectorAddress_arraysize);
    if (vectorAddress_arraysize==0) {
        this->vectorAddress_var = 0;
    } else {
        this->vectorAddress_var = new ::MACAddress[vectorAddress_arraysize];
        doUnpacking(b,this->vectorAddress_var,vectorAddress_arraysize);
    }
}

int LWMPLSPacket::getLabel() const
{
    return label_var;
}

void LWMPLSPacket::setLabel(int label_var)
{
    this->label_var = label_var;
}

int LWMPLSPacket::getLabelReturn() const
{
    return labelReturn_var;
}

void LWMPLSPacket::setLabelReturn(int labelReturn_var)
{
    this->labelReturn_var = labelReturn_var;
}

int LWMPLSPacket::getType() const
{
    return type_var;
}

void LWMPLSPacket::setType(int type_var)
{
    this->type_var = type_var;
}

bool LWMPLSPacket::getNextHeader() const
{
    return nextHeader_var;
}

void LWMPLSPacket::setNextHeader(bool nextHeader_var)
{
    this->nextHeader_var = nextHeader_var;
}

unsigned int LWMPLSPacket::getCounter() const
{
    return counter_var;
}

void LWMPLSPacket::setCounter(unsigned int counter_var)
{
    this->counter_var = counter_var;
}

MACAddress& LWMPLSPacket::getSource()
{
    return source_var;
}

void LWMPLSPacket::setSource(const MACAddress& source_var)
{
    this->source_var = source_var;
}

MACAddress& LWMPLSPacket::getDest()
{
    return dest_var;
}

void LWMPLSPacket::setDest(const MACAddress& dest_var)
{
    this->dest_var = dest_var;
}

void LWMPLSPacket::setVectorAddressArraySize(unsigned int size)
{
    ::MACAddress *vectorAddress_var2 = (size==0) ? NULL : new ::MACAddress[size];
    unsigned int sz = vectorAddress_arraysize < size ? vectorAddress_arraysize : size;
    for (unsigned int i=0; i<sz; i++)
        vectorAddress_var2[i] = this->vectorAddress_var[i];
    vectorAddress_arraysize = size;
    delete [] this->vectorAddress_var;
    this->vectorAddress_var = vectorAddress_var2;
}

unsigned int LWMPLSPacket::getVectorAddressArraySize() const
{
    return vectorAddress_arraysize;
}

MACAddress& LWMPLSPacket::getVectorAddress(unsigned int k)
{
    if (k>=vectorAddress_arraysize) throw cRuntimeError("Array of size %d indexed by %d", vectorAddress_arraysize, k);
    return vectorAddress_var[k];
}

void LWMPLSPacket::setVectorAddress(unsigned int k, const MACAddress& vectorAddress_var)
{
    if (k>=vectorAddress_arraysize) throw cRuntimeError("Array of size %d indexed by %d", vectorAddress_arraysize, k);
    this->vectorAddress_var[k]=vectorAddress_var;
}

class LWMPLSPacketDescriptor : public cClassDescriptor
{
  public:
    LWMPLSPacketDescriptor();
    virtual ~LWMPLSPacketDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(LWMPLSPacketDescriptor);

LWMPLSPacketDescriptor::LWMPLSPacketDescriptor() : cClassDescriptor("LWMPLSPacket", "cPacket")
{
}

LWMPLSPacketDescriptor::~LWMPLSPacketDescriptor()
{
}

bool LWMPLSPacketDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<LWMPLSPacket *>(obj)!=NULL;
}

const char *LWMPLSPacketDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int LWMPLSPacketDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 8+basedesc->getFieldCount(object) : 8;
}

unsigned int LWMPLSPacketDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISCOMPOUND,
        FD_ISCOMPOUND,
        FD_ISARRAY | FD_ISCOMPOUND,
    };
    return (field>=0 && field<8) ? fieldTypeFlags[field] : 0;
}

const char *LWMPLSPacketDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "label",
        "labelReturn",
        "type",
        "nextHeader",
        "counter",
        "source",
        "dest",
        "vectorAddress",
    };
    return (field>=0 && field<8) ? fieldNames[field] : NULL;
}

int LWMPLSPacketDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='l' && strcmp(fieldName, "label")==0) return base+0;
    if (fieldName[0]=='l' && strcmp(fieldName, "labelReturn")==0) return base+1;
    if (fieldName[0]=='t' && strcmp(fieldName, "type")==0) return base+2;
    if (fieldName[0]=='n' && strcmp(fieldName, "nextHeader")==0) return base+3;
    if (fieldName[0]=='c' && strcmp(fieldName, "counter")==0) return base+4;
    if (fieldName[0]=='s' && strcmp(fieldName, "source")==0) return base+5;
    if (fieldName[0]=='d' && strcmp(fieldName, "dest")==0) return base+6;
    if (fieldName[0]=='v' && strcmp(fieldName, "vectorAddress")==0) return base+7;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *LWMPLSPacketDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "int",
        "int",
        "bool",
        "unsigned int",
        "MACAddress",
        "MACAddress",
        "MACAddress",
    };
    return (field>=0 && field<8) ? fieldTypeStrings[field] : NULL;
}

const char *LWMPLSPacketDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 2:
            if (!strcmp(propertyname,"enum")) return "LwmplsType";
            return NULL;
        default: return NULL;
    }
}

int LWMPLSPacketDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    LWMPLSPacket *pp = (LWMPLSPacket *)object; (void)pp;
    switch (field) {
        case 7: return pp->getVectorAddressArraySize();
        default: return 0;
    }
}

std::string LWMPLSPacketDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    LWMPLSPacket *pp = (LWMPLSPacket *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getLabel());
        case 1: return long2string(pp->getLabelReturn());
        case 2: return long2string(pp->getType());
        case 3: return bool2string(pp->getNextHeader());
        case 4: return ulong2string(pp->getCounter());
        case 5: {std::stringstream out; out << pp->getSource(); return out.str();}
        case 6: {std::stringstream out; out << pp->getDest(); return out.str();}
        case 7: {std::stringstream out; out << pp->getVectorAddress(i); return out.str();}
        default: return "";
    }
}

bool LWMPLSPacketDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    LWMPLSPacket *pp = (LWMPLSPacket *)object; (void)pp;
    switch (field) {
        case 0: pp->setLabel(string2long(value)); return true;
        case 1: pp->setLabelReturn(string2long(value)); return true;
        case 2: pp->setType(string2long(value)); return true;
        case 3: pp->setNextHeader(string2bool(value)); return true;
        case 4: pp->setCounter(string2ulong(value)); return true;
        default: return false;
    }
}

const char *LWMPLSPacketDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldStructNames[] = {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        "MACAddress",
        "MACAddress",
        "MACAddress",
    };
    return (field>=0 && field<8) ? fieldStructNames[field] : NULL;
}

void *LWMPLSPacketDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    LWMPLSPacket *pp = (LWMPLSPacket *)object; (void)pp;
    switch (field) {
        case 5: return (void *)(&pp->getSource()); break;
        case 6: return (void *)(&pp->getDest()); break;
        case 7: return (void *)(&pp->getVectorAddress(i)); break;
        default: return NULL;
    }
}


