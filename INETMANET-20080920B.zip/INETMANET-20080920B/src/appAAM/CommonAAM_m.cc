// Copyright (C) 2011-2015 Salaheddin Darwish; Department of Computer Science, Brunel University London, UK
//
// Generated file, do not edit! Created by opp_msgc 4.1 from appAAM/CommonAAM.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "CommonAAM_m.h"

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
std::ostream& operator<<(std::ostream& out,const T&) {return out;}

// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




EXECUTE_ON_STARTUP(
    cEnum *e = cEnum::find("AAMMessageType");
    if (!e) enums.getInstance()->add(e = new cEnum("AAMMessageType"));
    e->insert(AAM_AUTHN_PROT_MSG1, "AAM_AUTHN_PROT_MSG1");
    e->insert(AAM_AUTHN_PROT_MSG2, "AAM_AUTHN_PROT_MSG2");
    e->insert(AAM_AUTHN_PROT_MSG3, "AAM_AUTHN_PROT_MSG3");
    e->insert(AAM_AUTHN_PROT_MSG4, "AAM_AUTHN_PROT_MSG4");
    e->insert(AAM_AUTHN_ACK, "AAM_AUTHN_ACK");
    e->insert(AAM_AUTHN_NOACK, "AAM_AUTHN_NOACK");
    e->insert(AAM_DAS_REQ, "AAM_DAS_REQ");
    e->insert(AAM_DAS_RESP, "AAM_DAS_RESP");
);

EXECUTE_ON_STARTUP(
    cEnum *e = cEnum::find("AAuthNProtoType");
    if (!e) enums.getInstance()->add(e = new cEnum("AAuthNProtoType"));
    e->insert(Unknown_Type, "Unknown_Type");
    e->insert(X509_One_Pass, "X509_One_Pass");
    e->insert(X509_Two_Pass, "X509_Two_Pass");
    e->insert(X509_Three_Pass, "X509_Three_Pass");
);

servicesTuple::servicesTuple()
{
    ID = 0;
    ServiceName = 0;
    ServiceAddress = 0;
    ServicePort = 0;
}

void doPacking(cCommBuffer *b, servicesTuple& a)
{
    doPacking(b,a.ID);
    doPacking(b,a.ServiceName);
    doPacking(b,a.ServiceAddress);
    doPacking(b,a.ServicePort);
}

void doUnpacking(cCommBuffer *b, servicesTuple& a)
{
    doUnpacking(b,a.ID);
    doUnpacking(b,a.ServiceName);
    doUnpacking(b,a.ServiceAddress);
    doUnpacking(b,a.ServicePort);
}

class servicesTupleDescriptor : public cClassDescriptor
{
  public:
    servicesTupleDescriptor();
    virtual ~servicesTupleDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(servicesTupleDescriptor);

servicesTupleDescriptor::servicesTupleDescriptor() : cClassDescriptor("servicesTuple", "")
{
}

servicesTupleDescriptor::~servicesTupleDescriptor()
{
}

bool servicesTupleDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<servicesTuple *>(obj)!=NULL;
}

const char *servicesTupleDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int servicesTupleDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 4+basedesc->getFieldCount(object) : 4;
}

unsigned int servicesTupleDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<4) ? fieldTypeFlags[field] : 0;
}

const char *servicesTupleDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "ID",
        "ServiceName",
        "ServiceAddress",
        "ServicePort",
    };
    return (field>=0 && field<4) ? fieldNames[field] : NULL;
}

int servicesTupleDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='I' && strcmp(fieldName, "ID")==0) return base+0;
    if (fieldName[0]=='S' && strcmp(fieldName, "ServiceName")==0) return base+1;
    if (fieldName[0]=='S' && strcmp(fieldName, "ServiceAddress")==0) return base+2;
    if (fieldName[0]=='S' && strcmp(fieldName, "ServicePort")==0) return base+3;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *servicesTupleDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "string",
        "string",
        "int",
    };
    return (field>=0 && field<4) ? fieldTypeStrings[field] : NULL;
}

const char *servicesTupleDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int servicesTupleDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    servicesTuple *pp = (servicesTuple *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string servicesTupleDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    servicesTuple *pp = (servicesTuple *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->ID);
        case 1: return oppstring2string(pp->ServiceName);
        case 2: return oppstring2string(pp->ServiceAddress);
        case 3: return long2string(pp->ServicePort);
        default: return "";
    }
}

bool servicesTupleDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    servicesTuple *pp = (servicesTuple *)object; (void)pp;
    switch (field) {
        case 0: pp->ID = string2long(value); return true;
        case 1: pp->ServiceName = (value); return true;
        case 2: pp->ServiceAddress = (value); return true;
        case 3: pp->ServicePort = string2long(value); return true;
        default: return false;
    }
}

const char *servicesTupleDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldStructNames[] = {
        NULL,
        NULL,
        NULL,
        NULL,
    };
    return (field>=0 && field<4) ? fieldStructNames[field] : NULL;
}

void *servicesTupleDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    servicesTuple *pp = (servicesTuple *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}

Register_Class(CommonAAM);

CommonAAM::CommonAAM(const char *name, int kind) : cPacket(name,kind)
{
    this->MsgType_var = 0;
    this->indxSrv_var = 0;
    this->SeqNum_var = 0;
}

CommonAAM::CommonAAM(const CommonAAM& other) : cPacket()
{
    setName(other.getName());
    operator=(other);
}

CommonAAM::~CommonAAM()
{
}

CommonAAM& CommonAAM::operator=(const CommonAAM& other)
{
    if (this==&other) return *this;
    cPacket::operator=(other);
    this->MsgType_var = other.MsgType_var;
    this->indxSrv_var = other.indxSrv_var;
    this->SeqNum_var = other.SeqNum_var;
    return *this;
}

void CommonAAM::parsimPack(cCommBuffer *b)
{
    cPacket::parsimPack(b);
    doPacking(b,this->MsgType_var);
    doPacking(b,this->indxSrv_var);
    doPacking(b,this->SeqNum_var);
}

void CommonAAM::parsimUnpack(cCommBuffer *b)
{
    cPacket::parsimUnpack(b);
    doUnpacking(b,this->MsgType_var);
    doUnpacking(b,this->indxSrv_var);
    doUnpacking(b,this->SeqNum_var);
}

int CommonAAM::getMsgType() const
{
    return MsgType_var;
}

void CommonAAM::setMsgType(int MsgType_var)
{
    this->MsgType_var = MsgType_var;
}

int CommonAAM::getIndxSrv() const
{
    return indxSrv_var;
}

void CommonAAM::setIndxSrv(int indxSrv_var)
{
    this->indxSrv_var = indxSrv_var;
}

int CommonAAM::getSeqNum() const
{
    return SeqNum_var;
}

void CommonAAM::setSeqNum(int SeqNum_var)
{
    this->SeqNum_var = SeqNum_var;
}

class CommonAAMDescriptor : public cClassDescriptor
{
  public:
    CommonAAMDescriptor();
    virtual ~CommonAAMDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(CommonAAMDescriptor);

CommonAAMDescriptor::CommonAAMDescriptor() : cClassDescriptor("CommonAAM", "cPacket")
{
}

CommonAAMDescriptor::~CommonAAMDescriptor()
{
}

bool CommonAAMDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<CommonAAM *>(obj)!=NULL;
}

const char *CommonAAMDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int CommonAAMDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 3+basedesc->getFieldCount(object) : 3;
}

unsigned int CommonAAMDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<3) ? fieldTypeFlags[field] : 0;
}

const char *CommonAAMDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "MsgType",
        "indxSrv",
        "SeqNum",
    };
    return (field>=0 && field<3) ? fieldNames[field] : NULL;
}

int CommonAAMDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='M' && strcmp(fieldName, "MsgType")==0) return base+0;
    if (fieldName[0]=='i' && strcmp(fieldName, "indxSrv")==0) return base+1;
    if (fieldName[0]=='S' && strcmp(fieldName, "SeqNum")==0) return base+2;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *CommonAAMDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "int",
        "int",
    };
    return (field>=0 && field<3) ? fieldTypeStrings[field] : NULL;
}

const char *CommonAAMDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 0:
            if (!strcmp(propertyname,"enum")) return "AAMMessageType";
            return NULL;
        default: return NULL;
    }
}

int CommonAAMDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    CommonAAM *pp = (CommonAAM *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string CommonAAMDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    CommonAAM *pp = (CommonAAM *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getMsgType());
        case 1: return long2string(pp->getIndxSrv());
        case 2: return long2string(pp->getSeqNum());
        default: return "";
    }
}

bool CommonAAMDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    CommonAAM *pp = (CommonAAM *)object; (void)pp;
    switch (field) {
        case 0: pp->setMsgType(string2long(value)); return true;
        case 1: pp->setIndxSrv(string2long(value)); return true;
        case 2: pp->setSeqNum(string2long(value)); return true;
        default: return false;
    }
}

const char *CommonAAMDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldStructNames[] = {
        NULL,
        NULL,
        NULL,
    };
    return (field>=0 && field<3) ? fieldStructNames[field] : NULL;
}

void *CommonAAMDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    CommonAAM *pp = (CommonAAM *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}

Register_Class(AuthenProtocolMsg);

AuthenProtocolMsg::AuthenProtocolMsg(const char *name, int kind) : CommonAAM(name,kind)
{
    this->Nonce_var = 0;
    this->Timestamp_var = 0;
    this->IdCertificate_var = 0;
    this->Signature_var = 0;
    this->length_var = 0;
    this->AuthNType_var = 0;
}

AuthenProtocolMsg::AuthenProtocolMsg(const AuthenProtocolMsg& other) : CommonAAM()
{
    setName(other.getName());
    operator=(other);
}

AuthenProtocolMsg::~AuthenProtocolMsg()
{
}

AuthenProtocolMsg& AuthenProtocolMsg::operator=(const AuthenProtocolMsg& other)
{
    if (this==&other) return *this;
    CommonAAM::operator=(other);
    this->Nonce_var = other.Nonce_var;
    this->Timestamp_var = other.Timestamp_var;
    this->IdCertificate_var = other.IdCertificate_var;
    this->Signature_var = other.Signature_var;
    this->length_var = other.length_var;
    this->AuthNType_var = other.AuthNType_var;
    return *this;
}

void AuthenProtocolMsg::parsimPack(cCommBuffer *b)
{
    CommonAAM::parsimPack(b);
    doPacking(b,this->Nonce_var);
    doPacking(b,this->Timestamp_var);
    doPacking(b,this->IdCertificate_var);
    doPacking(b,this->Signature_var);
    doPacking(b,this->length_var);
    doPacking(b,this->AuthNType_var);
}

void AuthenProtocolMsg::parsimUnpack(cCommBuffer *b)
{
    CommonAAM::parsimUnpack(b);
    doUnpacking(b,this->Nonce_var);
    doUnpacking(b,this->Timestamp_var);
    doUnpacking(b,this->IdCertificate_var);
    doUnpacking(b,this->Signature_var);
    doUnpacking(b,this->length_var);
    doUnpacking(b,this->AuthNType_var);
}

int AuthenProtocolMsg::getNonce() const
{
    return Nonce_var;
}

void AuthenProtocolMsg::setNonce(int Nonce_var)
{
    this->Nonce_var = Nonce_var;
}

const char * AuthenProtocolMsg::getTimestamp() const
{
    return Timestamp_var.c_str();
}

void AuthenProtocolMsg::setTimestamp(const char * Timestamp_var)
{
    this->Timestamp_var = Timestamp_var;
}

const char * AuthenProtocolMsg::getIdCertificate() const
{
    return IdCertificate_var.c_str();
}

void AuthenProtocolMsg::setIdCertificate(const char * IdCertificate_var)
{
    this->IdCertificate_var = IdCertificate_var;
}

const char * AuthenProtocolMsg::getSignature() const
{
    return Signature_var.c_str();
}

void AuthenProtocolMsg::setSignature(const char * Signature_var)
{
    this->Signature_var = Signature_var;
}

double AuthenProtocolMsg::getLength() const
{
    return length_var;
}

void AuthenProtocolMsg::setLength(double length_var)
{
    this->length_var = length_var;
}

int AuthenProtocolMsg::getAuthNType() const
{
    return AuthNType_var;
}

void AuthenProtocolMsg::setAuthNType(int AuthNType_var)
{
    this->AuthNType_var = AuthNType_var;
}

class AuthenProtocolMsgDescriptor : public cClassDescriptor
{
  public:
    AuthenProtocolMsgDescriptor();
    virtual ~AuthenProtocolMsgDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(AuthenProtocolMsgDescriptor);

AuthenProtocolMsgDescriptor::AuthenProtocolMsgDescriptor() : cClassDescriptor("AuthenProtocolMsg", "CommonAAM")
{
}

AuthenProtocolMsgDescriptor::~AuthenProtocolMsgDescriptor()
{
}

bool AuthenProtocolMsgDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<AuthenProtocolMsg *>(obj)!=NULL;
}

const char *AuthenProtocolMsgDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int AuthenProtocolMsgDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 6+basedesc->getFieldCount(object) : 6;
}

unsigned int AuthenProtocolMsgDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<6) ? fieldTypeFlags[field] : 0;
}

const char *AuthenProtocolMsgDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "Nonce",
        "Timestamp",
        "IdCertificate",
        "Signature",
        "length",
        "AuthNType",
    };
    return (field>=0 && field<6) ? fieldNames[field] : NULL;
}

int AuthenProtocolMsgDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='N' && strcmp(fieldName, "Nonce")==0) return base+0;
    if (fieldName[0]=='T' && strcmp(fieldName, "Timestamp")==0) return base+1;
    if (fieldName[0]=='I' && strcmp(fieldName, "IdCertificate")==0) return base+2;
    if (fieldName[0]=='S' && strcmp(fieldName, "Signature")==0) return base+3;
    if (fieldName[0]=='l' && strcmp(fieldName, "length")==0) return base+4;
    if (fieldName[0]=='A' && strcmp(fieldName, "AuthNType")==0) return base+5;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *AuthenProtocolMsgDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "int",
        "string",
        "string",
        "string",
        "double",
        "int",
    };
    return (field>=0 && field<6) ? fieldTypeStrings[field] : NULL;
}

const char *AuthenProtocolMsgDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 5:
            if (!strcmp(propertyname,"enum")) return "AAuthNProtoType";
            return NULL;
        default: return NULL;
    }
}

int AuthenProtocolMsgDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    AuthenProtocolMsg *pp = (AuthenProtocolMsg *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string AuthenProtocolMsgDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    AuthenProtocolMsg *pp = (AuthenProtocolMsg *)object; (void)pp;
    switch (field) {
        case 0: return long2string(pp->getNonce());
        case 1: return oppstring2string(pp->getTimestamp());
        case 2: return oppstring2string(pp->getIdCertificate());
        case 3: return oppstring2string(pp->getSignature());
        case 4: return double2string(pp->getLength());
        case 5: return long2string(pp->getAuthNType());
        default: return "";
    }
}

bool AuthenProtocolMsgDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    AuthenProtocolMsg *pp = (AuthenProtocolMsg *)object; (void)pp;
    switch (field) {
        case 0: pp->setNonce(string2long(value)); return true;
        case 1: pp->setTimestamp((value)); return true;
        case 2: pp->setIdCertificate((value)); return true;
        case 3: pp->setSignature((value)); return true;
        case 4: pp->setLength(string2double(value)); return true;
        case 5: pp->setAuthNType(string2long(value)); return true;
        default: return false;
    }
}

const char *AuthenProtocolMsgDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldStructNames[] = {
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
    };
    return (field>=0 && field<6) ? fieldStructNames[field] : NULL;
}

void *AuthenProtocolMsgDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    AuthenProtocolMsg *pp = (AuthenProtocolMsg *)object; (void)pp;
    switch (field) {
        default: return NULL;
    }
}

Register_Class(DataMsg);

DataMsg::DataMsg(const char *name, int kind) : CommonAAM(name,kind)
{
    this->AttrbCert_var = 0;
    this->ThreshAttrCert_var = 0;
    ServicesList_arraysize = 0;
    this->ServicesList_var = 0;
}

DataMsg::DataMsg(const DataMsg& other) : CommonAAM()
{
    setName(other.getName());
    ServicesList_arraysize = 0;
    this->ServicesList_var = 0;
    operator=(other);
}

DataMsg::~DataMsg()
{
    delete [] ServicesList_var;
}

DataMsg& DataMsg::operator=(const DataMsg& other)
{
    if (this==&other) return *this;
    CommonAAM::operator=(other);
    this->AttrbCert_var = other.AttrbCert_var;
    this->ThreshAttrCert_var = other.ThreshAttrCert_var;
    delete [] this->ServicesList_var;
    this->ServicesList_var = (other.ServicesList_arraysize==0) ? NULL : new ::servicesTuple[other.ServicesList_arraysize];
    ServicesList_arraysize = other.ServicesList_arraysize;
    for (unsigned int i=0; i<ServicesList_arraysize; i++)
        this->ServicesList_var[i] = other.ServicesList_var[i];
    return *this;
}

void DataMsg::parsimPack(cCommBuffer *b)
{
    CommonAAM::parsimPack(b);
    doPacking(b,this->AttrbCert_var);
    doPacking(b,this->ThreshAttrCert_var);
    b->pack(ServicesList_arraysize);
    doPacking(b,this->ServicesList_var,ServicesList_arraysize);
}

void DataMsg::parsimUnpack(cCommBuffer *b)
{
    CommonAAM::parsimUnpack(b);
    doUnpacking(b,this->AttrbCert_var);
    doUnpacking(b,this->ThreshAttrCert_var);
    delete [] this->ServicesList_var;
    b->unpack(ServicesList_arraysize);
    if (ServicesList_arraysize==0) {
        this->ServicesList_var = 0;
    } else {
        this->ServicesList_var = new ::servicesTuple[ServicesList_arraysize];
        doUnpacking(b,this->ServicesList_var,ServicesList_arraysize);
    }
}

const char * DataMsg::getAttrbCert() const
{
    return AttrbCert_var.c_str();
}

void DataMsg::setAttrbCert(const char * AttrbCert_var)
{
    this->AttrbCert_var = AttrbCert_var;
}

const char * DataMsg::getThreshAttrCert() const
{
    return ThreshAttrCert_var.c_str();
}

void DataMsg::setThreshAttrCert(const char * ThreshAttrCert_var)
{
    this->ThreshAttrCert_var = ThreshAttrCert_var;
}

void DataMsg::setServicesListArraySize(unsigned int size)
{
    ::servicesTuple *ServicesList_var2 = (size==0) ? NULL : new ::servicesTuple[size];
    unsigned int sz = ServicesList_arraysize < size ? ServicesList_arraysize : size;
    for (unsigned int i=0; i<sz; i++)
        ServicesList_var2[i] = this->ServicesList_var[i];
    ServicesList_arraysize = size;
    delete [] this->ServicesList_var;
    this->ServicesList_var = ServicesList_var2;
}

unsigned int DataMsg::getServicesListArraySize() const
{
    return ServicesList_arraysize;
}

servicesTuple& DataMsg::getServicesList(unsigned int k)
{
    if (k>=ServicesList_arraysize) throw cRuntimeError("Array of size %d indexed by %d", ServicesList_arraysize, k);
    return ServicesList_var[k];
}

void DataMsg::setServicesList(unsigned int k, const servicesTuple& ServicesList_var)
{
    if (k>=ServicesList_arraysize) throw cRuntimeError("Array of size %d indexed by %d", ServicesList_arraysize, k);
    this->ServicesList_var[k]=ServicesList_var;
}

class DataMsgDescriptor : public cClassDescriptor
{
  public:
    DataMsgDescriptor();
    virtual ~DataMsgDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(DataMsgDescriptor);

DataMsgDescriptor::DataMsgDescriptor() : cClassDescriptor("DataMsg", "CommonAAM")
{
}

DataMsgDescriptor::~DataMsgDescriptor()
{
}

bool DataMsgDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<DataMsg *>(obj)!=NULL;
}

const char *DataMsgDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int DataMsgDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 3+basedesc->getFieldCount(object) : 3;
}

unsigned int DataMsgDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISARRAY | FD_ISCOMPOUND,
    };
    return (field>=0 && field<3) ? fieldTypeFlags[field] : 0;
}

const char *DataMsgDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "AttrbCert",
        "ThreshAttrCert",
        "ServicesList",
    };
    return (field>=0 && field<3) ? fieldNames[field] : NULL;
}

int DataMsgDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='A' && strcmp(fieldName, "AttrbCert")==0) return base+0;
    if (fieldName[0]=='T' && strcmp(fieldName, "ThreshAttrCert")==0) return base+1;
    if (fieldName[0]=='S' && strcmp(fieldName, "ServicesList")==0) return base+2;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *DataMsgDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "string",
        "string",
        "servicesTuple",
    };
    return (field>=0 && field<3) ? fieldTypeStrings[field] : NULL;
}

const char *DataMsgDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int DataMsgDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    DataMsg *pp = (DataMsg *)object; (void)pp;
    switch (field) {
        case 2: return pp->getServicesListArraySize();
        default: return 0;
    }
}

std::string DataMsgDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    DataMsg *pp = (DataMsg *)object; (void)pp;
    switch (field) {
        case 0: return oppstring2string(pp->getAttrbCert());
        case 1: return oppstring2string(pp->getThreshAttrCert());
        case 2: {std::stringstream out; out << pp->getServicesList(i); return out.str();}
        default: return "";
    }
}

bool DataMsgDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    DataMsg *pp = (DataMsg *)object; (void)pp;
    switch (field) {
        case 0: pp->setAttrbCert((value)); return true;
        case 1: pp->setThreshAttrCert((value)); return true;
        default: return false;
    }
}

const char *DataMsgDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldStructNames[] = {
        NULL,
        NULL,
        "servicesTuple",
    };
    return (field>=0 && field<3) ? fieldStructNames[field] : NULL;
}

void *DataMsgDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    DataMsg *pp = (DataMsg *)object; (void)pp;
    switch (field) {
        case 2: return (void *)(&pp->getServicesList(i)); break;
        default: return NULL;
    }
}

Register_Class(AuthenReqMsg);

AuthenReqMsg::AuthenReqMsg(const char *name, int kind) : CommonAAM(name,kind)
{
    this->AuthenticatorPort_var = 0;
    this->AutNhBlock_var = 0;
}

AuthenReqMsg::AuthenReqMsg(const AuthenReqMsg& other) : CommonAAM()
{
    setName(other.getName());
    operator=(other);
}

AuthenReqMsg::~AuthenReqMsg()
{
}

AuthenReqMsg& AuthenReqMsg::operator=(const AuthenReqMsg& other)
{
    if (this==&other) return *this;
    CommonAAM::operator=(other);
    this->AuthenticatorAddress_var = other.AuthenticatorAddress_var;
    this->AuthenticatorPort_var = other.AuthenticatorPort_var;
    this->AutNhBlock_var = other.AutNhBlock_var;
    return *this;
}

void AuthenReqMsg::parsimPack(cCommBuffer *b)
{
    CommonAAM::parsimPack(b);
    doPacking(b,this->AuthenticatorAddress_var);
    doPacking(b,this->AuthenticatorPort_var);
    doPacking(b,this->AutNhBlock_var);
}

void AuthenReqMsg::parsimUnpack(cCommBuffer *b)
{
    CommonAAM::parsimUnpack(b);
    doUnpacking(b,this->AuthenticatorAddress_var);
    doUnpacking(b,this->AuthenticatorPort_var);
    doUnpacking(b,this->AutNhBlock_var);
}

IPvXAddress& AuthenReqMsg::getAuthenticatorAddress()
{
    return AuthenticatorAddress_var;
}

void AuthenReqMsg::setAuthenticatorAddress(const IPvXAddress& AuthenticatorAddress_var)
{
    this->AuthenticatorAddress_var = AuthenticatorAddress_var;
}

int AuthenReqMsg::getAuthenticatorPort() const
{
    return AuthenticatorPort_var;
}

void AuthenReqMsg::setAuthenticatorPort(int AuthenticatorPort_var)
{
    this->AuthenticatorPort_var = AuthenticatorPort_var;
}

const char * AuthenReqMsg::getAutNhBlock() const
{
    return AutNhBlock_var.c_str();
}

void AuthenReqMsg::setAutNhBlock(const char * AutNhBlock_var)
{
    this->AutNhBlock_var = AutNhBlock_var;
}

class AuthenReqMsgDescriptor : public cClassDescriptor
{
  public:
    AuthenReqMsgDescriptor();
    virtual ~AuthenReqMsgDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(AuthenReqMsgDescriptor);

AuthenReqMsgDescriptor::AuthenReqMsgDescriptor() : cClassDescriptor("AuthenReqMsg", "CommonAAM")
{
}

AuthenReqMsgDescriptor::~AuthenReqMsgDescriptor()
{
}

bool AuthenReqMsgDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<AuthenReqMsg *>(obj)!=NULL;
}

const char *AuthenReqMsgDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int AuthenReqMsgDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 3+basedesc->getFieldCount(object) : 3;
}

unsigned int AuthenReqMsgDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISCOMPOUND,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<3) ? fieldTypeFlags[field] : 0;
}

const char *AuthenReqMsgDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "AuthenticatorAddress",
        "AuthenticatorPort",
        "AutNhBlock",
    };
    return (field>=0 && field<3) ? fieldNames[field] : NULL;
}

int AuthenReqMsgDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='A' && strcmp(fieldName, "AuthenticatorAddress")==0) return base+0;
    if (fieldName[0]=='A' && strcmp(fieldName, "AuthenticatorPort")==0) return base+1;
    if (fieldName[0]=='A' && strcmp(fieldName, "AutNhBlock")==0) return base+2;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *AuthenReqMsgDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "IPvXAddress",
        "int",
        "string",
    };
    return (field>=0 && field<3) ? fieldTypeStrings[field] : NULL;
}

const char *AuthenReqMsgDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int AuthenReqMsgDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    AuthenReqMsg *pp = (AuthenReqMsg *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string AuthenReqMsgDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    AuthenReqMsg *pp = (AuthenReqMsg *)object; (void)pp;
    switch (field) {
        case 0: {std::stringstream out; out << pp->getAuthenticatorAddress(); return out.str();}
        case 1: return long2string(pp->getAuthenticatorPort());
        case 2: return oppstring2string(pp->getAutNhBlock());
        default: return "";
    }
}

bool AuthenReqMsgDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    AuthenReqMsg *pp = (AuthenReqMsg *)object; (void)pp;
    switch (field) {
        case 1: pp->setAuthenticatorPort(string2long(value)); return true;
        case 2: pp->setAutNhBlock((value)); return true;
        default: return false;
    }
}

const char *AuthenReqMsgDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldStructNames[] = {
        "IPvXAddress",
        NULL,
        NULL,
    };
    return (field>=0 && field<3) ? fieldStructNames[field] : NULL;
}

void *AuthenReqMsgDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    AuthenReqMsg *pp = (AuthenReqMsg *)object; (void)pp;
    switch (field) {
        case 0: return (void *)(&pp->getAuthenticatorAddress()); break;
        default: return NULL;
    }
}

Register_Class(AuthenResponsMsg);

AuthenResponsMsg::AuthenResponsMsg(const char *name, int kind) : CommonAAM(name,kind)
{
    this->AttrbCert_var = 0;
    ServicesList_arraysize = 0;
    this->ServicesList_var = 0;
}

AuthenResponsMsg::AuthenResponsMsg(const AuthenResponsMsg& other) : CommonAAM()
{
    setName(other.getName());
    ServicesList_arraysize = 0;
    this->ServicesList_var = 0;
    operator=(other);
}

AuthenResponsMsg::~AuthenResponsMsg()
{
    delete [] ServicesList_var;
}

AuthenResponsMsg& AuthenResponsMsg::operator=(const AuthenResponsMsg& other)
{
    if (this==&other) return *this;
    CommonAAM::operator=(other);
    this->AttrbCert_var = other.AttrbCert_var;
    delete [] this->ServicesList_var;
    this->ServicesList_var = (other.ServicesList_arraysize==0) ? NULL : new ::servicesTuple[other.ServicesList_arraysize];
    ServicesList_arraysize = other.ServicesList_arraysize;
    for (unsigned int i=0; i<ServicesList_arraysize; i++)
        this->ServicesList_var[i] = other.ServicesList_var[i];
    return *this;
}

void AuthenResponsMsg::parsimPack(cCommBuffer *b)
{
    CommonAAM::parsimPack(b);
    doPacking(b,this->AttrbCert_var);
    b->pack(ServicesList_arraysize);
    doPacking(b,this->ServicesList_var,ServicesList_arraysize);
}

void AuthenResponsMsg::parsimUnpack(cCommBuffer *b)
{
    CommonAAM::parsimUnpack(b);
    doUnpacking(b,this->AttrbCert_var);
    delete [] this->ServicesList_var;
    b->unpack(ServicesList_arraysize);
    if (ServicesList_arraysize==0) {
        this->ServicesList_var = 0;
    } else {
        this->ServicesList_var = new ::servicesTuple[ServicesList_arraysize];
        doUnpacking(b,this->ServicesList_var,ServicesList_arraysize);
    }
}

const char * AuthenResponsMsg::getAttrbCert() const
{
    return AttrbCert_var.c_str();
}

void AuthenResponsMsg::setAttrbCert(const char * AttrbCert_var)
{
    this->AttrbCert_var = AttrbCert_var;
}

void AuthenResponsMsg::setServicesListArraySize(unsigned int size)
{
    ::servicesTuple *ServicesList_var2 = (size==0) ? NULL : new ::servicesTuple[size];
    unsigned int sz = ServicesList_arraysize < size ? ServicesList_arraysize : size;
    for (unsigned int i=0; i<sz; i++)
        ServicesList_var2[i] = this->ServicesList_var[i];
    ServicesList_arraysize = size;
    delete [] this->ServicesList_var;
    this->ServicesList_var = ServicesList_var2;
}

unsigned int AuthenResponsMsg::getServicesListArraySize() const
{
    return ServicesList_arraysize;
}

servicesTuple& AuthenResponsMsg::getServicesList(unsigned int k)
{
    if (k>=ServicesList_arraysize) throw cRuntimeError("Array of size %d indexed by %d", ServicesList_arraysize, k);
    return ServicesList_var[k];
}

void AuthenResponsMsg::setServicesList(unsigned int k, const servicesTuple& ServicesList_var)
{
    if (k>=ServicesList_arraysize) throw cRuntimeError("Array of size %d indexed by %d", ServicesList_arraysize, k);
    this->ServicesList_var[k]=ServicesList_var;
}

class AuthenResponsMsgDescriptor : public cClassDescriptor
{
  public:
    AuthenResponsMsgDescriptor();
    virtual ~AuthenResponsMsgDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(AuthenResponsMsgDescriptor);

AuthenResponsMsgDescriptor::AuthenResponsMsgDescriptor() : cClassDescriptor("AuthenResponsMsg", "CommonAAM")
{
}

AuthenResponsMsgDescriptor::~AuthenResponsMsgDescriptor()
{
}

bool AuthenResponsMsgDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<AuthenResponsMsg *>(obj)!=NULL;
}

const char *AuthenResponsMsgDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int AuthenResponsMsgDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 2+basedesc->getFieldCount(object) : 2;
}

unsigned int AuthenResponsMsgDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,
        FD_ISARRAY | FD_ISCOMPOUND,
    };
    return (field>=0 && field<2) ? fieldTypeFlags[field] : 0;
}

const char *AuthenResponsMsgDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "AttrbCert",
        "ServicesList",
    };
    return (field>=0 && field<2) ? fieldNames[field] : NULL;
}

int AuthenResponsMsgDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='A' && strcmp(fieldName, "AttrbCert")==0) return base+0;
    if (fieldName[0]=='S' && strcmp(fieldName, "ServicesList")==0) return base+1;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *AuthenResponsMsgDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "string",
        "servicesTuple",
    };
    return (field>=0 && field<2) ? fieldTypeStrings[field] : NULL;
}

const char *AuthenResponsMsgDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int AuthenResponsMsgDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    AuthenResponsMsg *pp = (AuthenResponsMsg *)object; (void)pp;
    switch (field) {
        case 1: return pp->getServicesListArraySize();
        default: return 0;
    }
}

std::string AuthenResponsMsgDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    AuthenResponsMsg *pp = (AuthenResponsMsg *)object; (void)pp;
    switch (field) {
        case 0: return oppstring2string(pp->getAttrbCert());
        case 1: {std::stringstream out; out << pp->getServicesList(i); return out.str();}
        default: return "";
    }
}

bool AuthenResponsMsgDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    AuthenResponsMsg *pp = (AuthenResponsMsg *)object; (void)pp;
    switch (field) {
        case 0: pp->setAttrbCert((value)); return true;
        default: return false;
    }
}

const char *AuthenResponsMsgDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldStructNames[] = {
        NULL,
        "servicesTuple",
    };
    return (field>=0 && field<2) ? fieldStructNames[field] : NULL;
}

void *AuthenResponsMsgDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    AuthenResponsMsg *pp = (AuthenResponsMsg *)object; (void)pp;
    switch (field) {
        case 1: return (void *)(&pp->getServicesList(i)); break;
        default: return NULL;
    }
}


